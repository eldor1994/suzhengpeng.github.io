#include "kernel.h"
#include <stdio.h>
#include <stdlib.h>

// #include <cuda_runtime.h>
// #include <cuda_gl_interop.h>

#define N 320
#define M 480


int main ()
{
    Matrix A;
    Matrix B;
    Matrix C;

    float Mat_A[N*M] = { 0.0 };
    float Mat_B[N*M] = { 0.0 };
    float Mat_C[N*N] = { 0.0 };

    A.width = A.stride = B.height = N;
    A.height= B.stride = B.width  = M;

    C.width = C.stride = B.width;
    C.height= A.height;

    C.elements = Mat_C;
    B.elements = Mat_B;
    A.elements = Mat_A;

    for(int i = 0; i < N*M; i++)
    {
        A.elements[i] = 1.0f;
        B.elements[i] = 1.0f;
    }

    // printf("初始化完成");

    MatMul(A,B,C);

    FILE *outfile = fopen("results.csv", "w");
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            fprintf(outfile, "%f,", C.elements[i*N + j]);
        }
        fprintf(outfile, "\n");
    }
    fclose(outfile);

    return 0;
}