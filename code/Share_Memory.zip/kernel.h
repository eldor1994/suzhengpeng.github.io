#ifndef KERNEL_H
#define KERNEL_H

#define BLOCK_SIZE 16

// Matrices are stored in row-major order: 
// M(row, col) = *(M.elements + row * M.stride + col) 
typedef struct {    
    int width;   
    int height;    
    int stride;     
    float* elements;
    } Matrix; 

void MatMul(const Matrix A, const Matrix B, Matrix C);

#endif
